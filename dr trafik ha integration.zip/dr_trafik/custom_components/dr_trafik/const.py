"""Konstanter til DR Trafik integration."""

DOMAIN = "dr_trafik"
CONF_API_KEY = "api_key"
CONF_REGION = "region"
CONF_SCAN_INTERVAL = "scan_interval"
CONF_NOTIFY_NEW = "notify_new_incidents"
CONF_TYPES = "data_types"

DEFAULT_SCAN_INTERVAL = 5  # minutter
BASE_URL = "https://data.vd-nap.dk"
SNAPSHOT_ENDPOINT = "/api/v2/list/snapshot"

# Datafyper tilgængelige fra Vejdirektoratets NAP API
DATA_TYPES = {
    "traffic": "Trafikhændelser",
    "roadworks": "Vejarbejde",
    "wintercondition": "Vintervejforhold",
    "winterdeicing": "Glatførebekæmpelse",
}

# Regioner der svarer til DR's filtermuligheder
# Koordinater: SV (sydvest) og NØ (nordøst) hjørner
REGIONS = {
    "hele_landet": {
        "name": "Hele landet",
        "sw": None,
        "ne": None,
    },
    "kbh_sjaelland": {
        "name": "Kbh, Sjælland & øerne",
        "sw": "54.50,9.00",
        "ne": "56.20,15.70",
    },
    "midt_nord_ostjylland": {
        "name": "Midt-, Nord- & Østjylland",
        "sw": "55.50,9.40",
        "ne": "57.80,11.00",
    },
    "fyn_trekanten_sydjylland": {
        "name": "Fyn, Trekanten & Sydjylland",
        "sw": "54.80,8.60",
        "ne": "55.80,10.80",
    },
}

# Hændelseskategorier og ikoner
CATEGORY_ICONS = {
    "ACCIDENT": "mdi:car-emergency",
    "ACCIDENT_BLOCKING": "mdi:car-emergency",
    "ROADWORK": "mdi:road-variant",
    "ROADWORK_CLOSED": "mdi:road-variant",
    "LOCAL_ROADWORK": "mdi:road-variant",
    "ROADBLOCK": "mdi:barrier",
    "CONGESTION": "mdi:traffic-cone",
    "SLIPPERY": "mdi:snowflake-alert",
    "ICY": "mdi:snowflake-alert",
    "SNOW": "mdi:snowflake",
    "WIND": "mdi:weather-windy",
    "ALERT": "mdi:alert-circle",
    "ACTIVITY": "mdi:flag",
    "SPECIAL_EVENT": "mdi:calendar-star",
    "PARKING": "mdi:parking",
    "default": "mdi:traffic-light",
}

# Kategorier der altid skal udløse notifikation
CRITICAL_CATEGORIES = {
    "ACCIDENT_BLOCKING",
    "ROADBLOCK",
    "FUTURE_ROADBLOCK",
    "LOCAL_ROADBLOCK",
}

# Event-navn der affyres i HA når nye hændelser opdages
EVENT_NEW_INCIDENT = f"{DOMAIN}_new_incident"
