"""DataUpdateCoordinator til DR Trafik / Vejdirektoratet NAP API."""
from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any

import aiohttp

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import (
    BASE_URL,
    CRITICAL_CATEGORIES,
    DATA_TYPES,
    DOMAIN,
    EVENT_NEW_INCIDENT,
    REGIONS,
    SNAPSHOT_ENDPOINT,
)

_LOGGER = logging.getLogger(__name__)


class DRTrafikCoordinator(DataUpdateCoordinator):
    """Coordinator der henter trafikdata fra Vejdirektoratets NAP API."""

    def __init__(
        self,
        hass: HomeAssistant,
        api_key: str,
        region: str,
        data_types: list[str],
        scan_interval: int,
        notify_new: bool,
    ) -> None:
        """Initialisér coordinatoren."""
        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=timedelta(minutes=scan_interval),
        )
        self.api_key = api_key
        self.region = region
        self.data_types = data_types
        self.notify_new = notify_new
        self._known_tags: set[str] = set()
        self._first_run = True

    def _build_url(self) -> str:
        """Byg request-URL med parametre."""
        params = f"api_key={self.api_key}&types={','.join(self.data_types)}"
        region_cfg = REGIONS.get(self.region, REGIONS["hele_landet"])
        if region_cfg["sw"] and region_cfg["ne"]:
            params += f"&sw={region_cfg['sw']}&ne={region_cfg['ne']}"
        return f"{BASE_URL}{SNAPSHOT_ENDPOINT}?{params}"

    async def _async_update_data(self) -> dict[str, Any]:
        """Hent og processér trafikdata."""
        url = self._build_url()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                    if resp.status == 401:
                        raise UpdateFailed("Ugyldig API-nøgle – tjek din NAP API-nøgle")
                    if resp.status != 200:
                        raise UpdateFailed(f"API returnerede statuskode {resp.status}")
                    raw: list[dict] = await resp.json()
        except aiohttp.ClientError as err:
            raise UpdateFailed(f"Netværksfejl ved hentning af trafikdata: {err}") from err

        # Organisér data pr. type
        incidents: dict[str, list[dict]] = {t: [] for t in self.data_types}
        for item in raw:
            entity_type = item.get("entityType", "").lower()
            for dtype in self.data_types:
                if dtype in entity_type or entity_type in dtype:
                    incidents[dtype].append(item)
                    break
            else:
                # Fallback: tilføj til første type
                if self.data_types:
                    incidents[self.data_types[0]].append(item)

        # Find nye hændelser og affyr events
        current_tags = {item.get("tag", "") for sublist in incidents.values() for item in sublist}
        if not self._first_run and self.notify_new:
            new_tags = current_tags - self._known_tags
            for sublist in incidents.values():
                for item in sublist:
                    if item.get("tag") in new_tags:
                        self._fire_new_incident_event(item)

        self._known_tags = current_tags
        self._first_run = False

        return {
            "incidents": incidents,
            "total_count": sum(len(v) for v in incidents.values()),
            "region_name": REGIONS.get(self.region, {}).get("name", self.region),
        }

    def _fire_new_incident_event(self, item: dict) -> None:
        """Affyr HA-event for ny hændelse."""
        self.hass.bus.async_fire(
            EVENT_NEW_INCIDENT,
            {
                "tag": item.get("tag"),
                "heading": item.get("heading", ""),
                "description": item.get("description", ""),
                "entity_type": item.get("entityType", ""),
                "timestamp": item.get("timestamp", ""),
                "region": self.region,
                "is_critical": item.get("entityType", "") in CRITICAL_CATEGORIES,
            },
        )
        _LOGGER.info(
            "Ny trafikhændelse: %s – %s",
            item.get("heading", ""),
            item.get("description", ""),
        )
