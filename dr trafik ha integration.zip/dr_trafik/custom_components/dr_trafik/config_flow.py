"""Config flow til DR Trafik integration."""
from __future__ import annotations

import logging
from typing import Any

import aiohttp
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import HomeAssistant, callback
from homeassistant.data_entry_flow import FlowResult
import homeassistant.helpers.config_validation as cv

from .const import (
    BASE_URL,
    CONF_API_KEY,
    CONF_NOTIFY_NEW,
    CONF_REGION,
    CONF_SCAN_INTERVAL,
    CONF_TYPES,
    DATA_TYPES,
    DEFAULT_SCAN_INTERVAL,
    DOMAIN,
    REGIONS,
    SNAPSHOT_ENDPOINT,
)

_LOGGER = logging.getLogger(__name__)


async def _validate_api_key(hass: HomeAssistant, api_key: str) -> str | None:
    """Returnér None ved succes, fejlbesked ved fejl."""
    url = f"{BASE_URL}{SNAPSHOT_ENDPOINT}?api_key={api_key}&types=traffic"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 401:
                    return "invalid_auth"
                if resp.status != 200:
                    return "cannot_connect"
    except aiohttp.ClientError:
        return "cannot_connect"
    return None


class DRTrafikConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Config flow til opsætning af DR Trafik."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Håndtér brugerens første trin: API-nøgle."""
        errors: dict[str, str] = {}

        if user_input is not None:
            error = await _validate_api_key(self.hass, user_input[CONF_API_KEY])
            if error:
                errors["base"] = error
            else:
                return self.async_create_entry(
                    title=f"DR Trafik – {REGIONS[user_input[CONF_REGION]]['name']}",
                    data={
                        CONF_API_KEY: user_input[CONF_API_KEY],
                        CONF_REGION: user_input[CONF_REGION],
                        CONF_SCAN_INTERVAL: user_input[CONF_SCAN_INTERVAL],
                        CONF_NOTIFY_NEW: user_input[CONF_NOTIFY_NEW],
                        CONF_TYPES: user_input[CONF_TYPES],
                    },
                )

        region_options = {k: v["name"] for k, v in REGIONS.items()}
        type_options = {k: v for k, v in DATA_TYPES.items()}

        schema = vol.Schema(
            {
                vol.Required(CONF_API_KEY): str,
                vol.Required(CONF_REGION, default="hele_landet"): vol.In(region_options),
                vol.Required(CONF_SCAN_INTERVAL, default=DEFAULT_SCAN_INTERVAL): vol.All(
                    vol.Coerce(int), vol.Range(min=1, max=60)
                ),
                vol.Required(CONF_TYPES, default=["traffic", "roadworks"]): cv.multi_select(
                    type_options
                ),
                vol.Required(CONF_NOTIFY_NEW, default=True): bool,
            }
        )

        return self.async_show_form(
            step_id="user",
            data_schema=schema,
            errors=errors,
            description_placeholders={
                "nap_url": "https://nap.vd.dk/themes/1"
            },
        )

    @staticmethod
    @callback
    def async_get_options_flow(
        config_entry: config_entries.ConfigEntry,
    ) -> DRTrafikOptionsFlow:
        """Returnér options flow."""
        return DRTrafikOptionsFlow(config_entry)


class DRTrafikOptionsFlow(config_entries.OptionsFlow):
    """Options flow til at ændre indstillinger."""

    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        """Initialisér."""
        self.config_entry = config_entry

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Håndtér options-trin."""
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        current = self.config_entry.data
        region_options = {k: v["name"] for k, v in REGIONS.items()}
        type_options = {k: v for k, v in DATA_TYPES.items()}

        schema = vol.Schema(
            {
                vol.Required(
                    CONF_REGION, default=current.get(CONF_REGION, "hele_landet")
                ): vol.In(region_options),
                vol.Required(
                    CONF_SCAN_INTERVAL,
                    default=current.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL),
                ): vol.All(vol.Coerce(int), vol.Range(min=1, max=60)),
                vol.Required(
                    CONF_TYPES, default=current.get(CONF_TYPES, ["traffic", "roadworks"])
                ): cv.multi_select(type_options),
                vol.Required(
                    CONF_NOTIFY_NEW, default=current.get(CONF_NOTIFY_NEW, True)
                ): bool,
            }
        )

        return self.async_show_form(step_id="init", data_schema=schema)
