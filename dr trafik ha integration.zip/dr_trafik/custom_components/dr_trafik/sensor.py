"""Sensor-platform til DR Trafik integration."""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.components.sensor import SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import (
    CATEGORY_ICONS,
    DATA_TYPES,
    DOMAIN,
    REGIONS,
)
from .coordinator import DRTrafikCoordinator

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Opret sensor-entiteter."""
    coordinator: DRTrafikCoordinator = hass.data[DOMAIN][entry.entry_id]

    entities: list[SensorEntity] = []

    # Overordnet sensor: samlet antal aktive meldinger
    entities.append(DRTrafikTotalSensor(coordinator, entry))

    # Én sensor pr. datatype
    for dtype in coordinator.data_types:
        entities.append(DRTrafikTypeSensor(coordinator, entry, dtype))

    # Sensor der viser den seneste/mest alvorlige melding som tekst
    entities.append(DRTrafikLatestSensor(coordinator, entry))

    async_add_entities(entities, True)


class _DRTrafikBaseSensor(CoordinatorEntity[DRTrafikCoordinator], SensorEntity):
    """Basisklasse med fælles device-info."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: DRTrafikCoordinator, entry: ConfigEntry) -> None:
        """Initialisér."""
        super().__init__(coordinator)
        self._entry = entry
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=f"DR Trafik – {REGIONS.get(coordinator.region, {}).get('name', coordinator.region)}",
            manufacturer="Vejdirektoratet",
            model="NAP Trafikdata API",
            configuration_url="https://nap.vd.dk/themes/1",
        )


class DRTrafikTotalSensor(_DRTrafikBaseSensor):
    """Sensor der viser det samlede antal aktive trafikhændelser."""

    _attr_icon = "mdi:traffic-light"
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_native_unit_of_measurement = "meldinger"

    def __init__(self, coordinator: DRTrafikCoordinator, entry: ConfigEntry) -> None:
        """Initialisér."""
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.entry_id}_total"
        self._attr_name = "Aktive meldinger i alt"

    @property
    def native_value(self) -> int:
        """Returner samlet antal meldinger."""
        if not self.coordinator.data:
            return 0
        return self.coordinator.data.get("total_count", 0)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Ekstra attributter."""
        if not self.coordinator.data:
            return {}
        return {
            "region": self.coordinator.data.get("region_name", ""),
            "opdateret": self.coordinator.last_update_success_time.isoformat()
            if self.coordinator.last_update_success_time
            else None,
        }


class DRTrafikTypeSensor(_DRTrafikBaseSensor):
    """Sensor pr. datatype (trafikhændelser, vejarbejde osv.)."""

    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_native_unit_of_measurement = "meldinger"

    def __init__(
        self,
        coordinator: DRTrafikCoordinator,
        entry: ConfigEntry,
        dtype: str,
    ) -> None:
        """Initialisér."""
        super().__init__(coordinator, entry)
        self._dtype = dtype
        self._attr_unique_id = f"{entry.entry_id}_{dtype}"
        self._attr_name = DATA_TYPES.get(dtype, dtype.capitalize())
        self._attr_icon = (
            "mdi:road-variant"
            if dtype == "roadworks"
            else "mdi:car-emergency"
            if dtype == "traffic"
            else "mdi:snowflake"
        )

    @property
    def native_value(self) -> int:
        """Antal meldinger for denne type."""
        if not self.coordinator.data:
            return 0
        return len(self.coordinator.data.get("incidents", {}).get(self._dtype, []))

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Eksportér listen af meldinger som attributter."""
        if not self.coordinator.data:
            return {}
        items = self.coordinator.data.get("incidents", {}).get(self._dtype, [])
        return {
            "meldinger": [
                {
                    "overskrift": item.get("heading", ""),
                    "beskrivelse": item.get("description", ""),
                    "kategori": item.get("entityType", ""),
                    "tidsstempel": item.get("timestamp", ""),
                    "tag": item.get("tag", ""),
                }
                for item in items[:20]  # Max 20 for at undgå for store attributter
            ],
            "total": len(items),
        }


class DRTrafikLatestSensor(_DRTrafikBaseSensor):
    """Sensor der viser den seneste trafikmelding som tilstand."""

    _attr_icon = "mdi:alert-circle-outline"

    def __init__(self, coordinator: DRTrafikCoordinator, entry: ConfigEntry) -> None:
        """Initialisér."""
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.entry_id}_latest"
        self._attr_name = "Seneste melding"

    @property
    def native_value(self) -> str:
        """Returner overskrift på nyeste melding, eller 'Ingen aktive meldinger'."""
        latest = self._get_latest_item()
        if latest:
            return latest.get("heading", "Ukendt melding")[:255]
        return "Ingen aktive meldinger"

    @property
    def icon(self) -> str:
        """Ikon baseret på kategori."""
        latest = self._get_latest_item()
        if latest:
            cat = latest.get("entityType", "")
            return CATEGORY_ICONS.get(cat, CATEGORY_ICONS["default"])
        return "mdi:check-circle-outline"

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Detaljer om den seneste melding."""
        latest = self._get_latest_item()
        if not latest:
            return {"aktiv": False}
        return {
            "aktiv": True,
            "overskrift": latest.get("heading", ""),
            "beskrivelse": latest.get("description", ""),
            "kategori": latest.get("entityType", ""),
            "tidsstempel": latest.get("timestamp", ""),
            "tag": latest.get("tag", ""),
        }

    def _get_latest_item(self) -> dict | None:
        """Find den seneste hændelse på tværs af alle typer."""
        if not self.coordinator.data:
            return None
        all_items = []
        for items in self.coordinator.data.get("incidents", {}).values():
            all_items.extend(items)
        if not all_items:
            return None
        # Sortér efter tidsstempel, nyeste først
        try:
            all_items.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        except Exception:
            pass
        return all_items[0]
