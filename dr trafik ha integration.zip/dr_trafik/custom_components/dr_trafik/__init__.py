"""DR Trafik integration til Home Assistant.

Henter trafikdata fra Vejdirektoratets NAP API – samme datakilde som dr.dk/trafik.

Opsætning:
  1. Opret konto og generér gratis API-nøgle på https://nap.vd.dk/themes/1
  2. Tilføj integrationen via Indstillinger → Enheder & tjenester → Tilføj integration
  3. Søg efter "DR Trafik"
"""
from __future__ import annotations

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant

from .const import (
    CONF_API_KEY,
    CONF_NOTIFY_NEW,
    CONF_REGION,
    CONF_SCAN_INTERVAL,
    CONF_TYPES,
    DEFAULT_SCAN_INTERVAL,
    DOMAIN,
)
from .coordinator import DRTrafikCoordinator

_LOGGER = logging.getLogger(__name__)

PLATFORMS: list[Platform] = [Platform.SENSOR]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Opsæt integrationen fra en config-entry."""
    hass.data.setdefault(DOMAIN, {})

    # Hent konfiguration – fald tilbage til entry.data hvis options er tomme
    cfg = {**entry.data, **entry.options}

    coordinator = DRTrafikCoordinator(
        hass=hass,
        api_key=cfg[CONF_API_KEY],
        region=cfg.get(CONF_REGION, "hele_landet"),
        data_types=cfg.get(CONF_TYPES, ["traffic", "roadworks"]),
        scan_interval=cfg.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL),
        notify_new=cfg.get(CONF_NOTIFY_NEW, True),
    )

    await coordinator.async_config_entry_first_refresh()
    hass.data[DOMAIN][entry.entry_id] = coordinator

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    # Lyt til options-opdateringer
    entry.async_on_unload(entry.add_update_listener(_async_update_listener))

    _LOGGER.info("DR Trafik integration opsat – region: %s", cfg.get(CONF_REGION))
    return True


async def _async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Genindlæs entry når options ændres."""
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Afmontér integrationen."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id)
    return unload_ok
